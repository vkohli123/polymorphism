public class Main {
 public static void main(String[]args ){
   item coke= new item("coke","drink", 1.50);
   coke.printItem();
   coke.setSize("LARGE");
   coke.printItem();
   item avocado = new item ("Topping","avacado",1.50);
   avocado.printItem();
 }
}