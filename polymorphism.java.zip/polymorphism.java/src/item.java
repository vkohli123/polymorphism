public class item {
    private String type;
    private String name;
    private double price;
    private String size="MEDIUM";

    public item(String name, String type, double price) {
        this.name = name.toUpperCase();
        this.type = type.toUpperCase();
        this.price = price;
    }

    public String getName() {
        if(type.equals("SIDES")||type.equals("DRINK")){
            return size+" "+ name;
        }
        return name;
    }
        public double getAdjustedPrice(){
        return switch(size){
            case "SMALL"-> getBasePrice() -0.5;
            case "LARGE"-> getBasePrice()+1;
            default -> getBasePrice();
        };
    }

    public double getBasePrice() {
        return price;
    }

    public void setSize(String size) {
        this.size = size;
    }
    public static void printItem(String name,double Price){
        System.out.printf("%20s:%6.2f%n",name,Price);
    }
    public void printItem(){
        printItem(getName(),getAdjustedPrice());
    }
}
